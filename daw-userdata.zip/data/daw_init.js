// daw_context_init.js is included


// daw.loadTrack("test-groups-1");


// d.stop();
// // d.loadFile("C:/Users/Michael/daw/run/loop2.project", FLAG_DEFER_LOAD);
// dawPath="C:/Users/Michael/daw/run/"
// d.loadFile(dawPath+"group-proj-1.project", FLAG_DEFER_LOAD);
// d.setEmptyProject();
// d.menuCommand(CMD_INSERT_MIDI_TRACK);
// d.menuCommand(CMD_INSERT_MIDI_TRACK);
// d.saveFile(dawPath+"test-save.project")
// d.loadFile(dawPath+"test-save.project", FLAG_DEFER_LOAD)
// daw.loadTrackDeferred("Piano - Pure Emotions");
// daw.loadTrack("projects-converted/154p");
// daw.loadTrack("projects-converted/kol");
// daw.loadTrackDeferred("test-routing");
// daw.loadTrackDeferred("303");
// daw.loadTrackDeferred("a41-cessna");
// daw.loadTrackDeferred("C:\Users\Michael\daw\run\my-projects\mpower");
// daw.loadTrackDeferred("sine mood_v2_test2")
// daw.loadTrackDeferred("84bpm midfi"); # large project, takes time to load especially in debug buidls
//daw.loadTrackDeferred("pure moog");
//daw.loadTrack("redone2")

//printTrackInfo();