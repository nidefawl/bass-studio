//startup.js

dawInstance.saveTrack = function(projName) {
    if (dawInstance) {
        dawPath="C:/Users/Michael/daw/run/";
        dawInstance.saveFile(dawPath+projName+".project");
    }
}
dawInstance.loadTrack = function(projName) {
    if (dawInstance) {
        dawPath="C:/Users/Michael/daw/run/";
        var flags = 0x0; // no defer load
        dawInstance.loadFile(dawPath+projName+".project", flags);
    }
}
dawInstance.loadTrackDeferred = function(projName) {
    if (dawInstance) {
        dawPath="C:/Users/Michael/daw/run/";
        var flags = 0x1; // defer load
        dawInstance.loadFile(dawPath+projName+".project", flags);
    }
}
daw=dawInstance;

var CMD_EXIT = 1;
var CMD_FILE_NEW = 2;
var CMD_FILE_OPEN = 3;
var CMD_FILE_SAVE = 4;
var CMD_FILE_SAVEAS = 5;
var CMD_FILE_CLOSE = 6;
var CMD_UNDO = 10;
var CMD_REDO = 11;
var CMD_CUT = 12;
var CMD_COPY = 13;
var CMD_PASTE = 14;
var CMD_DELETE = 15;
var CMD_SELECT_ALL = 16;
var CMD_DUPLICATE = 17;
var CMD_PREFERENCES = 18;
var CMD_ABOUT = 19;
var CMD_SHOW_DEBUG_WINDOW = 20;
var CMD_INSERT_AUDIO_TRACK = 21;
var CMD_INSERT_MIDI_TRACK = 22;
var CMD_INSERT_RETURN_TRACK = 24;
var CMD_INSERT_MASTER_TRACK = 25;

var FLAG_DEFER_LOAD = 0x1

function printTrackInfo() {
    var graph = getAudioGraph("test");
    var trackInfo = getTrackInfo("test");
        
    var nodesFlat = [];
    var visitedNodes = [];
    for (var i = 0; i < graph.roots.length; i++) {
        var rootIdx = graph.roots[i];
        var gStack = [];
        gStack.push(rootIdx);
        while (gStack.length > 0) {
            var nodeIdx = gStack.pop();
            if (visitedNodes.indexOf(nodeIdx) > -1) {
                print("Already visited");
                continue;
            }
            visitedNodes.push(nodeIdx);
            var node = graph.nodes[nodeIdx];
            // print("gStack "+gStack);
            // print("node "+node);
            // print("node.dependencies "+node.dependencies);
            // print("node.dependencies.length "+node.dependencies.length);
            gStack = node.dependencies.concat(gStack);
            // print("gStack2 "+gStack);
            var name = trackInfo.tracks[nodeIdx];
            nodesFlat.push({'name': name, 'stageId': node.stageId });
            // print("node.dependencies "+node.dependencies);
        }
    }
    nodesFlatRev = nodesFlat.reverse();
    var str = "";
    for (var idx in nodesFlatRev) {
        if (str.length) str+=";";
        str+=nodesFlatRev[idx].name;
    }
    print("nodesFlatRev "+str);
    for (var idx in nodesFlatRev) {
        print("Process "+nodesFlatRev[idx].name);
    }
}