//daw_dummy.js
dawInstance={}